// Fill out your copyright notice in the Description page of Project Settings.


#include "GasCharacter.h"
#include <GASDemoRene/Public/Core/Components/GasDemoAbilitySystemComponent.h>
#include <GASDemoRene/Public/Core/Abilities/DemoCharacterAttributeSet.h>
#include <Core/Abilities/DemoGameplayAbility.h> // include forward declared class

// Sets default values
AGasCharacter::AGasCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	bAbilitiesInitialized = false;

	AbilitySystemComponent = CreateDefaultSubobject<UGasDemoAbilitySystemComponent>(TEXT("Ability System"));
	AbilitySystemComponent->SetIsReplicated(true);
	AbilitySystemComponent->SetReplicationMode(EGameplayEffectReplicationMode::Minimal);

	Attributes = CreateDefaultSubobject<UDemoCharacterAttributeSet>(TEXT("Attributes"));
}

float AGasCharacter::GetHealth()
{
	if (Attributes)
	{
		return Attributes->GetHealth();
	}
	return 42.0f;
}

float AGasCharacter::GetMaxHealth()
{
	if (Attributes)
	{
		return Attributes->GetMaxHealth();
	}
	return 42.0f;
}

float AGasCharacter::GetMana()
{
	if (Attributes)
	{
		return Attributes->GetMana();
	}
	return 42.0f;
}

float AGasCharacter::GetMaxMana()
{
	if (Attributes)
	{
		return Attributes->GetMaxMana();
	}
	return 42.0f;
}

float AGasCharacter::GetSpeed()
{
	if (Attributes)
	{
		return Attributes->GetSpeed();
	}
	return 0.0f;
}

void AGasCharacter::BeginPlay()
{
	Super::BeginPlay();
}

void AGasCharacter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	// Init server GAS
	if (AbilitySystemComponent)
	{
		AbilitySystemComponent->InitAbilityActorInfo(this, this);
		AddStartupAbilities();
	}
}

void AGasCharacter::OnRep_PlayerState()
{
	Super::OnRep_PlayerState();

	// Client Side
	AbilitySystemComponent->InitAbilityActorInfo(this, this);

	if (AbilitySystemComponent && InputComponent)
	{
		const FGameplayAbilityInputBinds Binds(
			"Confirm",
			"Cancel",
			FTopLevelAssetPath(GetPathNameSafe(UClass::TryFindTypeSlow<UEnum>("EDemoAbilityInputID"))),
			static_cast<int32>(EDemoAbilityInputID::Confirm),
			static_cast<int32>(EDemoAbilityInputID::Cancel));

		AbilitySystemComponent->BindAbilityActivationToInputComponent(InputComponent, Binds);
	}
}


// Called to bind functionality to input
void AGasCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	if (AbilitySystemComponent && InputComponent)
	{
		const FGameplayAbilityInputBinds Binds(
			"Confirm",
			"Cancel",
			"EDemoAbilityInputID",
			static_cast<int32>(EDemoAbilityInputID::Confirm),
			static_cast<int32>(EDemoAbilityInputID::Cancel));

		AbilitySystemComponent->BindAbilityActivationToInputComponent(InputComponent, Binds);
	}
}

UAbilitySystemComponent* AGasCharacter::GetAbilitySystemComponent() const
{
	return AbilitySystemComponent;
}

void AGasCharacter::AddStartupAbilities()
{
	check(AbilitySystemComponent);

	if (GetLocalRole() == ROLE_Authority && !bAbilitiesInitialized)
	{
		//Grant abilities only on the server
		for (TSubclassOf<UDemoGameplayAbility>& StartupAbility : GameplayAbilities)
		{
			AbilitySystemComponent->GiveAbility(FGameplayAbilitySpec(
				StartupAbility,
				1,
				static_cast<int32>(StartupAbility.GetDefaultObject()->AbilityInputID),
				this));
		}

		// Attribute overrides
		for (const TSubclassOf<UGameplayEffect>& GameplayEffect : PassiveGameplayEffects)
		{
			FGameplayEffectContextHandle EffectContext = AbilitySystemComponent->MakeEffectContext();
			EffectContext.AddSourceObject(this);
		
			FGameplayEffectSpecHandle NewHandle = AbilitySystemComponent->MakeOutgoingSpec(
				GameplayEffect, 1, EffectContext);

			if (NewHandle.IsValid())
			{
				FActiveGameplayEffectHandle ActiveGameplayEffectHandle = AbilitySystemComponent->ApplyGameplayEffectSpecToTarget(
					*NewHandle.Data.Get(), AbilitySystemComponent);
			}
		}

		bAbilitiesInitialized = true;
	}
}

void AGasCharacter::HandleDamage(float DamageAmount, const FHitResult& HitInfo, const FGameplayTagContainer& DamageTags, AGasCharacter* InstigatorCharacter, AActor* DamageCauser)
{
	OnDamaged(DamageAmount, HitInfo, DamageTags, InstigatorCharacter, DamageCauser);
}

void AGasCharacter::HandleHealthChanged(float DeltaValue, const FGameplayTagContainer& EventTags)
{
	if (bAbilitiesInitialized)
	{
		OnHealthChanged(DeltaValue, EventTags);
	}
}

void AGasCharacter::HandleSpeedChanged(float DeltaValue, const FGameplayTagContainer& EventTags)
{
	if (bAbilitiesInitialized)
	{
		OnSpeedChanged(DeltaValue, EventTags);
	}
}

void AGasCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


